# Инструкция по запуску FestOrg Manager на другом компьютере

1. **Установите Python 3.11 или новее**  
   - Скачать: https://www.python.org/downloads/  
   - При установке отметьте "Add Python to PATH"

2. **Установите MySQL Server**  
   - Скачать: https://dev.mysql.com/downloads/installer/  
   - Установите и запомните пароль пользователя root  
   - Создайте базу данных festorg (можно через MySQL Workbench или командную строку)

3. **Скопируйте папку festorg_manager на целевой компьютер**  
   - Можно через флешку, облако, архив и т.д.

4. **Откройте командную строку или PowerShell в папке festorg_manager**

5. **Установите зависимости:**  
   pip install -r requirements.txt

6. **Настройте подключение к MySQL**  
   - Откройте файл src/database.py  
   - Укажите свои параметры подключения: host, user, password, database

7. **Запустите проект:**  
   python src/main.py

8. **(Опционально) Соберите exe-файл:**  
   python -m PyInstaller --onefile --windowed src/main.py --icon=src/icons/festorg.ico  
   - Готовый exe будет в папке dist

9. **Если база пустая — создайте таблицы и тестовые данные через SQL-скрипт**

### Быстрое создание базы данных и таблиц

1. Откройте MySQL Workbench или командную строку MySQL.
2. Выполните следующий SQL-скрипт (можно скопировать из festorg_db.sql):

```sql
CREATE DATABASE IF NOT EXISTS festorg CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE festorg;

CREATE TABLE IF NOT EXISTS participants (
   participant_id INT AUTO_INCREMENT PRIMARY KEY,
   name VARCHAR(100) NOT NULL,
   role VARCHAR(50) NOT NULL,
   contact_info VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS venues (
   venue_id INT AUTO_INCREMENT PRIMARY KEY,
   name VARCHAR(100) NOT NULL,
   address VARCHAR(255),
   capacity INT
);

CREATE TABLE IF NOT EXISTS schedule (
   event_id INT AUTO_INCREMENT PRIMARY KEY,
   name VARCHAR(100) NOT NULL,
   date DATE NOT NULL,
   time TIME NOT NULL,
   venue_id INT,
   FOREIGN KEY (venue_id) REFERENCES venues(venue_id) ON DELETE SET NULL
);

-- Пример заполнения
INSERT INTO venues (name, address, capacity) VALUES ('Base', 'ул. Примерная, 1', 100);
INSERT INTO participants (name, role, contact_info) VALUES ('Иван Иванов', 'артист', 'ivan@example.com');
INSERT INTO schedule (name, date, time, venue_id) VALUES ('Открытие', '2025-10-22', '18:00:00', 1);
```

3. После этого база готова к работе!

10. **Готово! Теперь можно показать работу преподавателю**

---

**Важно:**  
- Если MySQL установлен не локально, измените host на адрес сервера  
- Если возникнут ошибки — проверьте параметры подключения и наличие всех зависимостей

# FestOrg Manager

## Установка
1. Установите Python 3.11+
2. Установите MySQL и создайте базу festorg
3. Установите зависимости:
   pip install -r requirements.txt

## Запуск
- Для запуска: python src/main.py
- Для сборки exe: python -m PyInstaller --onefile --windowed src/main.py --icon=src/icons/festorg.ico

## Настройка MySQL
- Укажите свои параметры подключения в src/database.py

## Структура
- src/ — исходный код
- src/icons/ — иконки
