import pymysql

class Database:
    def __init__(self):
        try:
            self.conn = pymysql.connect(
                host="localhost",
                user="root",           # замените на свой пользователь
                password="Gafmaccrn1488",     # замените на свой пароль
                database="festorg",
                port=3306,
                charset="utf8mb4",
                cursorclass=pymysql.cursors.DictCursor
            )
            self.cursor = self.conn.cursor()
            print("✅ Подключение к базе MySQL успешно")
        except pymysql.MySQLError as e:
            print("❌ Ошибка подключения к базе:")
            print(e)
            self.conn = None
            self.cursor = None

    def fetch(self, query, params=None):
        self.cursor.execute(query, params or ())
        return self.cursor.fetchall()

    def execute(self, query, params=None):
        try:
            self.cursor.execute(query, params or ())
            self.conn.commit()
        except Exception as e:
            print("❌ Ошибка выполнения запроса:", e)
            self.conn.rollback()
            raise

    def close(self):
        if self.conn:
            self.conn.close()
            print("✅ Соединение закрыто")
