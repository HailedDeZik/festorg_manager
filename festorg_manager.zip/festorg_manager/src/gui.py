import tkinter as tk
from tkinter import ttk, messagebox
from database import Database
from PIL import Image, ImageTk
from datetime import datetime

# Пример базового интерфейса
class App(tk.Tk):
    def schedule_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text="Расписание")

        tree_frame = ttk.Frame(frame)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=10)
        self.event_tree = ttk.Treeview(tree_frame, columns=("id", "date", "time", "venue", "name"), show="headings", selectmode="browse")
        self.event_tree.heading("id", text="ID")
        self.event_tree.column("id", width=40, anchor="center")
        self.event_tree.heading("name", text="Название")
        self.event_tree.column("name", width=180, anchor="w")
        self.event_tree.heading("date", text="Дата")
        self.event_tree.column("date", width=100, anchor="center")
        self.event_tree.heading("time", text="Время")
        self.event_tree.column("time", width=80, anchor="center")
        self.event_tree.heading("venue", text="Площадка")
        self.event_tree.column("venue", width=180, anchor="w")
        self.event_tree.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.event_tree.yview)
        scrollbar.pack(side="right", fill="y")
        self.event_tree.configure(yscrollcommand=scrollbar.set)



        form_frame = ttk.LabelFrame(frame, text="Добавить мероприятие", padding=10)
        form_frame.pack(fill="x", padx=10, pady=10)
        ttk.Label(form_frame, text="Название:").grid(row=0, column=0, padx=5, pady=5)
        self.event_name_entry = ttk.Entry(form_frame, width=20)
        self.event_name_entry.grid(row=0, column=1, padx=5, pady=5)
        ttk.Label(form_frame, text="Дата:").grid(row=0, column=2, padx=5, pady=5)
        self.event_date_entry = ttk.Entry(form_frame, width=12)
        self.event_date_entry.grid(row=0, column=3, padx=5, pady=5)
        ttk.Label(form_frame, text="Время:").grid(row=0, column=4, padx=5, pady=5)
        self.event_time_entry = ttk.Entry(form_frame, width=8)
        self.event_time_entry.grid(row=0, column=5, padx=5, pady=5)
        ttk.Label(form_frame, text="Площадка:").grid(row=0, column=6, padx=5, pady=5)
        self.event_venue_combo = ttk.Combobox(form_frame, width=18)
        self.event_venue_combo.grid(row=0, column=7, padx=5, pady=5)
        ttk.Button(form_frame, text="Добавить", command=self.add_event).grid(row=0, column=8, padx=5, pady=5)
        btns_frame = ttk.Frame(frame)
        btns_frame.pack(pady=5)
        ttk.Button(btns_frame, text="Редактировать выбранное", command=self.edit_event_dialog).pack(side="left", padx=5)
        ttk.Button(btns_frame, text="Удалить выбранное", command=self.delete_event).pack(side="left", padx=5)
        ttk.Button(btns_frame, text="Экспорт в CSV", command=self.export_schedule_csv).pack(side="left", padx=5)
    def export_schedule_csv(self):
        import csv
        from tkinter import filedialog
        rows = self.db.fetch("SELECT * FROM schedule ORDER BY event_id")
        venues = {v['venue_id']: v['name'] for v in self.db.fetch("SELECT venue_id, name FROM venues")}
        file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")], title="Сохранить расписание как CSV")
        if not file_path:
            return
        with open(file_path, "w", newline='', encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["ID", "Название", "Дата", "Время", "Площадка"])
            for row in rows:
                eid, name, date, time, venue_id = row.values() if isinstance(row, dict) else row
                venue_name = venues.get(venue_id, "-")
                writer.writerow([eid, name, date, time, venue_name])
        messagebox.showinfo("Экспорт", f"Расписание успешно экспортировано в файл:\n{file_path}")

        self.load_events()

    def load_events(self):
        for i in self.event_tree.get_children():
            self.event_tree.delete(i)
        venues = {v['venue_id']: v['name'] for v in self.db.fetch("SELECT venue_id, name FROM venues")}
        rows = self.db.fetch("SELECT * FROM schedule ORDER BY event_id")
        print("DEBUG schedule rows:", rows)
        for row in rows:
            eid, name, date, time, venue_id = row.values() if isinstance(row, dict) else row
            # Преобразование даты и времени в строку
            if isinstance(date, (str, bytes)):
                date_str = date
            else:
                date_str = date.strftime("%Y-%m-%d")
            if isinstance(time, str):
                time_str = time
            elif hasattr(time, 'seconds'):
                # time как timedelta
                total_seconds = time.seconds
                hours = total_seconds // 3600
                minutes = (total_seconds % 3600) // 60
                time_str = f"{hours:02d}:{minutes:02d}"
            else:
                time_str = str(time)
            venue_name = venues.get(venue_id, "-")
            icon = self.icons.get("venue")
            self.event_tree.insert("", "end", text=name, image=icon, values=(eid, date_str, time_str, venue_name))
        # Заполнить список площадок для формы
        self.event_venue_combo['values'] = list(venues.values())

    def add_event(self):
        name = self.event_name_entry.get().strip()
        date = self.event_date_entry.get().strip()
        # Автоматическое преобразование даты
        from datetime import datetime
        try:
            if '.' in date:
                date = datetime.strptime(date, "%d.%m.%Y").strftime("%Y-%m-%d")
        except ValueError:
            messagebox.showwarning("Ошибка", "Дата должна быть в формате ДД.ММ.ГГГГ или ГГГГ-ММ-ДД")
            return
        time = self.event_time_entry.get().strip()
        venue_name = self.event_venue_combo.get().strip()
        if not name or not date or not time or not venue_name:
            messagebox.showwarning("Ошибка", "Заполните все поля")
            return
        # Получить venue_id по названию
        venue_row = self.db.fetch("SELECT venue_id FROM venues WHERE name=%s", (venue_name,))
        if not venue_row:
            messagebox.showwarning("Ошибка", "Площадка не найдена")
            return
        venue_id = venue_row[0][0] if isinstance(venue_row[0], (list, tuple)) else venue_row[0]['venue_id']
        print(f"DEBUG: venue_id={venue_id}, name={name}, date={date}, time={time}, venue_name={venue_name}")
        self.db.execute("INSERT INTO schedule (name, date, time, venue_id) VALUES (%s, %s, %s, %s)", (name, date, time, venue_id))
        # ...создание формы...
        # ...создание кнопок...
        self.load_events()
        self.event_name_entry.delete(0, tk.END)
        self.event_date_entry.delete(0, tk.END)
        self.event_time_entry.delete(0, tk.END)
        self.event_venue_combo.set("")

    def edit_event_dialog(self):
        selected = self.event_tree.selection()
        if not selected:
            messagebox.showwarning("Ошибка", "Выберите мероприятие для редактирования")
            return
        item = self.event_tree.item(selected[0])
        eid, date, time, venue_name, name = item["values"]

        dialog = tk.Toplevel(self)
        dialog.title("Редактировать мероприятие")
        dialog.geometry("400x250")
        dialog.transient(self)
        dialog.grab_set()

        tk.Label(dialog, text="Название:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
        name_entry = ttk.Entry(dialog, width=25)
        name_entry.insert(0, name)
        name_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(dialog, text="Дата:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
        date_entry = ttk.Entry(dialog, width=12)
        date_entry.insert(0, date)
        date_entry.grid(row=1, column=1, padx=10, pady=10)

        tk.Label(dialog, text="Время:").grid(row=2, column=0, padx=10, pady=10, sticky="e")
        time_entry = ttk.Entry(dialog, width=8)
        time_entry.insert(0, time)
        time_entry.grid(row=2, column=1, padx=10, pady=10)

        tk.Label(dialog, text="Площадка:").grid(row=3, column=0, padx=10, pady=10, sticky="e")
        venue_combo = ttk.Combobox(dialog, width=18)
        venues = [v[1] for v in self.db.fetch("SELECT venue_id, name FROM venues")]
        venue_combo['values'] = venues
        venue_combo.set(venue_name)
        venue_combo.grid(row=3, column=1, padx=10, pady=10)

        def save():
            new_name = name_entry.get().strip()
            new_date = date_entry.get().strip()
            new_time = time_entry.get().strip()
            new_venue_name = venue_combo.get().strip()
            if not new_name or not new_date or not new_time or not new_venue_name:
                messagebox.showwarning("Ошибка", "Заполните все поля")
                return
            venue_row = self.db.fetch("SELECT venue_id FROM venues WHERE name=%s", (new_venue_name,))
            if not venue_row:
                messagebox.showwarning("Ошибка", "Площадка не найдена")
                return
            venue_id = venue_row[0][0] if isinstance(venue_row[0], (list, tuple)) else venue_row[0]['venue_id']
            self.db.execute(
                "UPDATE schedule SET name=%s, date=%s, time=%s, venue_id=%s WHERE event_id=%s",
                (new_name, new_date, new_time, venue_id, eid)
            )
            self.load_events()
            dialog.destroy()

        ttk.Button(dialog, text="Сохранить", command=save).grid(row=4, column=0, columnspan=2, pady=15)

    def delete_event(self):
        selected = self.event_tree.selection()
        if not selected:
            messagebox.showwarning("Ошибка", "Выберите мероприятие для удаления")
            return
        eid = self.event_tree.item(selected[0])["values"][0]
        self.db.execute("DELETE FROM schedule WHERE event_id = %s", (eid,))
        self.load_events()
    def __init__(self):
        super().__init__()
        self.db = Database()
        self.title("FestOrg - Система управления фестивалями")
        self.geometry("1000x700")
        self.configure(bg="#f0f0f0")

        # Иконка приложения
        try:
            self.iconbitmap("src/icons/festorg.ico")
        except:
            print("Иконка не найдена")

        # Notebook
        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill="both", padx=10, pady=10)

        # Стили для Treeview
        style = ttk.Style()
        style.configure("Treeview", font=("Arial", 11), rowheight=30)
        style.configure("Treeview.Heading", font=("Arial", 12, "bold"), background="#007ACC", foreground="#222222")

        # Загрузка иконок
        def load_icon(path):
            try:
                img = Image.open(path).resize((24, 24), Image.LANCZOS)
                return ImageTk.PhotoImage(img)
            except:
                return None

        self.icons = {
            "артист": load_icon("src/icons/artist.png"),
            "волонтер": load_icon("src/icons/volunteer.png"),
            "организатор": load_icon("src/icons/organizer.png"),
            "venue": load_icon("src/icons/venue.png")
        }

        # Вкладки
        self.participants_tab()
        self.venues_tab()
        self.schedule_tab()

    # ---------------- Участники ----------------
    def participants_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text="Участники")

        # Treeview
        tree_frame = ttk.Frame(frame)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=10)
        self.tree = ttk.Treeview(tree_frame, columns=("id", "role", "contact"), show="tree headings", selectmode="browse")
        self.tree.heading("#0", text="Имя")
        self.tree.column("#0", width=180, anchor="w")
        self.tree.heading("id", text="ID")
        self.tree.column("id", width=40, anchor="center")
        self.tree.heading("role", text="Роль")
        self.tree.column("role", width=100, anchor="center")
        self.tree.heading("contact", text="Контакты")
        self.tree.column("contact", width=180, anchor="w")
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        scrollbar.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.bind("<Motion>", self.on_tree_hover)
        self.load_participants()

        # Форма добавления
        form_frame = ttk.LabelFrame(frame, text="Добавить участника", padding=10)
        form_frame.pack(fill="x", padx=10, pady=10)
        ttk.Label(form_frame, text="Имя:").grid(row=0, column=0, padx=5, pady=5)
        self.name_entry = ttk.Entry(form_frame, width=20)
        self.name_entry.grid(row=0, column=1, padx=5, pady=5)
        ttk.Label(form_frame, text="Роль:").grid(row=0, column=2, padx=5, pady=5)
        self.role_entry = ttk.Combobox(form_frame, values=["артист", "волонтер", "организатор"], width=18)
        self.role_entry.grid(row=0, column=3, padx=5, pady=5)
        ttk.Label(form_frame, text="Контакты:").grid(row=0, column=4, padx=5, pady=5)
        self.contact_entry = ttk.Entry(form_frame, width=25)
        self.contact_entry.grid(row=0, column=5, padx=5, pady=5)
        ttk.Button(form_frame, text="Добавить", command=self.add_participant).grid(row=0, column=6, padx=5, pady=5)
        btns_frame = ttk.Frame(frame)
        btns_frame.pack(pady=5)
        ttk.Button(btns_frame, text="Редактировать выбранного", command=self.edit_participant_dialog).pack(side="left", padx=5)
        ttk.Button(btns_frame, text="Удалить выбранного", command=self.delete_participant).pack(side="left", padx=5)
        ttk.Button(btns_frame, text="Экспорт в CSV", command=self.export_participants_csv).pack(side="left", padx=5)

    def export_participants_csv(self):
        import csv
        from tkinter import filedialog
        rows = self.db.fetch("SELECT * FROM participants ORDER BY participant_id")
        file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")], title="Сохранить участников как CSV")
        if not file_path:
            return
        with open(file_path, "w", newline='', encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["ID", "Имя", "Роль", "Контакты"])
            for row in rows:
                pid, name, role, contact = row.values() if isinstance(row, dict) else row
                writer.writerow([pid, name, role, contact])
        messagebox.showinfo("Экспорт", f"Участники успешно экспортированы в файл:\n{file_path}")

    def edit_participant_dialog(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Ошибка", "Выберите участника для редактирования")
            return
        item = self.tree.item(selected[0])
        pid, role, contact = item["values"]
        name = item["text"]

        dialog = tk.Toplevel(self)
        dialog.title("Редактировать участника")
        dialog.geometry("400x220")
        dialog.transient(self)
        dialog.grab_set()

        tk.Label(dialog, text="Имя:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
        name_entry = ttk.Entry(dialog, width=25)
        name_entry.insert(0, name)
        name_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(dialog, text="Роль:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
        role_entry = ttk.Combobox(dialog, values=["артист", "волонтер", "организатор"], width=22)
        role_entry.set(role)
        role_entry.grid(row=1, column=1, padx=10, pady=10)

        tk.Label(dialog, text="Контакты:").grid(row=2, column=0, padx=10, pady=10, sticky="e")
        contact_entry = ttk.Entry(dialog, width=25)
        contact_entry.insert(0, contact)
        contact_entry.grid(row=2, column=1, padx=10, pady=10)

        def save():
            new_name = name_entry.get().strip()
            new_role = role_entry.get()
            new_contact = contact_entry.get().strip()
            if not new_name or not new_role:
                messagebox.showwarning("Ошибка", "Имя и роль обязательны")
                return
            self.db.execute(
                "UPDATE participants SET name=%s, role=%s, contact_info=%s WHERE participant_id=%s",
                (new_name, new_role, new_contact, pid)
            )
            self.load_participants()
            dialog.destroy()

        ttk.Button(dialog, text="Сохранить", command=save).grid(row=3, column=0, columnspan=2, pady=15)

    def load_participants(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        self.tree.tag_configure("артист", foreground="#155724", background="#d4edda")
        self.tree.tag_configure("волонтер", foreground="#0c5460", background="#d1ecf1")
        self.tree.tag_configure("организатор", foreground="#856404", background="#fff3cd")
        rows = self.db.fetch("SELECT * FROM participants ORDER BY participant_id")
        for row in rows:
            pid, name, role, contact = row.values() if isinstance(row, dict) else row
            icon = self.icons.get(role)
            self.tree.insert("", "end", text=name, image=icon, values=(pid, role, contact), tags=(role,))

    def on_tree_hover(self, event):
        item = self.tree.identify_row(event.y)
        if item:
            self.tree.selection_set(item)

    def add_participant(self):
        name = self.name_entry.get().strip()
        role = self.role_entry.get()
        contact = self.contact_entry.get().strip()
        if not name or not role:
            messagebox.showwarning("Ошибка", "Введите имя и роль")
            return
        self.db.execute("INSERT INTO participants (name, role, contact_info) VALUES (%s, %s, %s)", (name, role, contact))
        self.load_participants()
        self.name_entry.delete(0, tk.END)
        self.role_entry.set("")
        self.contact_entry.delete(0, tk.END)

    def delete_participant(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showwarning("Ошибка", "Выберите участника для удаления")
            return
        pid = self.tree.item(selected[0])["values"][0]
        self.db.execute("DELETE FROM participants WHERE participant_id = %s", (pid,))
        self.load_participants()

    # ---------------- Площадки ----------------
    def venues_tab(self):
        frame = ttk.Frame(self.notebook)
        self.notebook.add(frame, text="Площадки")

        tree_frame = ttk.Frame(frame)
        tree_frame.pack(fill="both", expand=True, padx=10, pady=10)
        self.venue_tree = ttk.Treeview(tree_frame, columns=("id", "address", "capacity"), show="tree headings", selectmode="browse")
        self.venue_tree.heading("#0", text="Название")
        self.venue_tree.column("#0", width=180, anchor="w")
        self.venue_tree.heading("id", text="ID")
        self.venue_tree.column("id", width=40, anchor="center")
        self.venue_tree.heading("address", text="Адрес")
        self.venue_tree.column("address", width=200, anchor="w")
        self.venue_tree.heading("capacity", text="Вместимость")
        self.venue_tree.column("capacity", width=100, anchor="center")
        self.venue_tree.pack(side="left", fill="both", expand=True)
        scrollbar = ttk.Scrollbar(tree_frame, orient="vertical", command=self.venue_tree.yview)
        scrollbar.pack(side="right", fill="y")
        self.venue_tree.configure(yscrollcommand=scrollbar.set)

        self.load_venues()

        form_frame = ttk.LabelFrame(frame, text="Добавить площадку", padding=10)
        form_frame.pack(fill="x", padx=10, pady=10)
        ttk.Label(form_frame, text="Название:").grid(row=0, column=0, padx=5, pady=5)
        self.venue_name_entry = ttk.Entry(form_frame, width=20)
        self.venue_name_entry.grid(row=0, column=1, padx=5, pady=5)
        ttk.Label(form_frame, text="Адрес:").grid(row=0, column=2, padx=5, pady=5)
        self.venue_address_entry = ttk.Entry(form_frame, width=30)
        self.venue_address_entry.grid(row=0, column=3, padx=5, pady=5)
        ttk.Label(form_frame, text="Вместимость:").grid(row=0, column=4, padx=5, pady=5)
        self.venue_capacity_entry = ttk.Entry(form_frame, width=10)
        self.venue_capacity_entry.grid(row=0, column=5, padx=5, pady=5)
        ttk.Button(form_frame, text="Добавить", command=self.add_venue).grid(row=0, column=6, padx=5, pady=5)
        btns_frame = ttk.Frame(frame)
        btns_frame.pack(pady=5)
        ttk.Button(btns_frame, text="Редактировать выбранную", command=self.edit_venue_dialog).pack(side="left", padx=5)
        ttk.Button(btns_frame, text="Удалить выбранную", command=self.delete_venue).pack(side="left", padx=5)
        ttk.Button(btns_frame, text="Экспорт в CSV", command=self.export_venues_csv).pack(side="left", padx=5)
    def export_venues_csv(self):
        import csv
        from tkinter import filedialog
        rows = self.db.fetch("SELECT * FROM venues ORDER BY venue_id")
        file_path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV files", "*.csv")], title="Сохранить площадки как CSV")
        if not file_path:
            return
        with open(file_path, "w", newline='', encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["ID", "Название", "Адрес", "Вместимость"])
            for row in rows:
                vid, name, address, capacity = row.values() if isinstance(row, dict) else row
                writer.writerow([vid, name, address, capacity])
        messagebox.showinfo("Экспорт", f"Площадки успешно экспортированы в файл:\n{file_path}")

    def load_venues(self):
        for i in self.venue_tree.get_children():
            self.venue_tree.delete(i)
        rows = self.db.fetch("SELECT * FROM venues ORDER BY venue_id")
        for row in rows:
            vid, name, address, capacity = row.values() if isinstance(row, dict) else row
            icon = self.icons.get("venue")
            self.venue_tree.insert("", "end", text=name, image=icon, values=(vid, address, capacity))

    def add_venue(self):
        name = self.venue_name_entry.get().strip()
        address = self.venue_address_entry.get().strip()
        capacity = self.venue_capacity_entry.get().strip()
        if not name:
            messagebox.showwarning("Ошибка", "Введите название площадки")
            return
        try:
            cap = int(capacity) if capacity else None
        except ValueError:
            messagebox.showwarning("Ошибка", "Вместимость должна быть числом")
            return
        self.db.execute("INSERT INTO venues (name, address, capacity) VALUES (%s, %s, %s)", (name, address, cap))
        self.load_venues()
        self.venue_name_entry.delete(0, tk.END)
        self.venue_address_entry.delete(0, tk.END)
        self.venue_capacity_entry.delete(0, tk.END)

    def edit_venue_dialog(self):
        selected = self.venue_tree.selection()
        if not selected:
            messagebox.showwarning("Ошибка", "Выберите площадку для редактирования")
            return
        item = self.venue_tree.item(selected[0])
        vid, address, capacity = item["values"]
        name = item["text"]

        dialog = tk.Toplevel(self)
        dialog.title("Редактировать площадку")
        dialog.geometry("400x220")
        dialog.transient(self)
        dialog.grab_set()

        tk.Label(dialog, text="Название:").grid(row=0, column=0, padx=10, pady=10, sticky="e")
        name_entry = ttk.Entry(dialog, width=25)
        name_entry.insert(0, name)
        name_entry.grid(row=0, column=1, padx=10, pady=10)

        tk.Label(dialog, text="Адрес:").grid(row=1, column=0, padx=10, pady=10, sticky="e")
        address_entry = ttk.Entry(dialog, width=30)
        address_entry.insert(0, address)
        address_entry.grid(row=1, column=1, padx=10, pady=10)

        tk.Label(dialog, text="Вместимость:").grid(row=2, column=0, padx=10, pady=10, sticky="e")
        capacity_entry = ttk.Entry(dialog, width=10)
        capacity_entry.insert(0, str(capacity))
        capacity_entry.grid(row=2, column=1, padx=10, pady=10)

        def save():
            new_name = name_entry.get().strip()
            new_address = address_entry.get().strip()
            try:
                new_capacity = int(capacity_entry.get().strip()) if capacity_entry.get().strip() else None
            except ValueError:
                messagebox.showwarning("Ошибка", "Вместимость должна быть числом")
                return
            if not new_name:
                messagebox.showwarning("Ошибка", "Название обязательно")
                return
            self.db.execute(
                "UPDATE venues SET name=%s, address=%s, capacity=%s WHERE venue_id=%s",
                (new_name, new_address, new_capacity, vid)
            )
            self.load_venues()
            dialog.destroy()

        ttk.Button(dialog, text="Сохранить", command=save).grid(row=3, column=0, columnspan=2, pady=15)

    def delete_venue(self):
        selected = self.venue_tree.selection()
        if not selected:
            messagebox.showwarning("Ошибка", "Выберите площадку для удаления")
            return
        vid = self.venue_tree.item(selected[0])["values"][0]
        self.db.execute("DELETE FROM venues WHERE venue_id = %s", (vid,))
        self.load_venues()
