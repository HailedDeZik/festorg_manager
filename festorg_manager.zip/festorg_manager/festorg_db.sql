-- festorg_db.sql
-- Скрипт для создания базы данных и всех таблиц для FestOrg

CREATE DATABASE IF NOT EXISTS festorg CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE festorg;

-- Таблица участников
CREATE TABLE IF NOT EXISTS participants (
    participant_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(50) NOT NULL,
    contact_info VARCHAR(255)
);

-- Таблица площадок
CREATE TABLE IF NOT EXISTS venues (
    venue_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(255),
    capacity INT
);

-- Таблица расписания
CREATE TABLE IF NOT EXISTS schedule (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    venue_id INT,
    FOREIGN KEY (venue_id) REFERENCES venues(venue_id) ON DELETE SET NULL
);

-- Пример заполнения
INSERT INTO venues (name, address, capacity) VALUES ('Base', 'ул. Примерная, 1', 100);
INSERT INTO participants (name, role, contact_info) VALUES ('Иван Иванов', 'артист', 'ivan@example.com');
INSERT INTO schedule (name, date, time, venue_id) VALUES ('Открытие', '2025-10-22', '18:00:00', 1);
